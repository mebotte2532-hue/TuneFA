"use strict";window.theme={tH:function(){if(!window.apk)
return 0;return window.apk.sizes.navBarHeight},singleBgExtra:function(){var b=document.body,$btn,below;if(!b||!b.classList.contains("mobile")||b.classList.contains("page_m_track_single")||b.classList.contains("page_m_album_single"))return 0;if(!$(document).find(".page_content.single").length)return 0;$btn=$(document).find("body.mobile .page_content.single .d_head .detail .buttons").first();if(!$btn.length)return 0;below=parseFloat(window.getComputedStyle(b).getPropertyValue("--tf-single-bg-below"));if(isNaN(below))below=26;return Math.max(0,Math.round($btn.outerHeight()-5+below))},run:function(){$(document).on("ui_page_event",function(event,$args){var _event=$args.event;var _page=$args.page;if(_event=="ready"){window.theme.settings.ready(_page);if(window.app.config?window.app.config.mobile:!1){if($(document).find(".d_head.t2 .detail .is").length?$(document).find(".d_head.t2 .detail .is").offset():!1){$("body #main .content .page_bg:not(.dropColor)").css("height",Math.ceil(window.theme.tH()+$(document).find(".d_head.t2 .detail .is").offset().top+$(document).find(".d_head.t2 .detail .is").outerHeight()))}else if($(document).find("body.mobile .d_head .detail .buttons").length?$(document).find("body.mobile .d_head .detail .buttons").offset():!1){$("body #main .content .page_bg:not(.dropColor)").css("height",Math.ceil($(document).find("body.mobile .d_head .detail .buttons").offset().top+5+window.theme.singleBgExtra()))}}
if(_page?(_page.theme_file?(_page.theme_file=="pages/_series"||_page.theme_file=="pages/_post"||_page.theme_file=="pages/_single"||_page.theme_file=="pages/_creator"):!1):!1){if(!window.ui.page.curr().data.becli.single.data.background_color&&window.ui.page.curr().data.becli.single.data.cover&&!window.ui.page.curr().data.becli.single.data.background){window.bof._loadExtension({name:"Vibrant",path:"vibrant.min.js",base:"https://cdn.jsdelivr.net/npm/node-vibrant@3.1.5/dist/",dir:"",skipNameCheck:!0,}).done(function(){var path=window.ui.page.curr().data.becli.single.data.cover.split("src=\"")[1].split("\"")[0];var __mp=0;var color=null;Vibrant.from(path+(path.includes("?bof=")?"":((path.includes("?")?"&":"?")+"bof=dont_cache"))).quality(5).getPalette(function(err,palette){if(!err&&palette){for(var i=0;i<Object.keys(palette).length;i++){var palette_i_key=Object.keys(palette)[i];var pallete_i=palette[palette_i_key];if(pallete_i.population>__mp){__mp=pallete_i.population;color=pallete_i.rgb.join(", ")}}
$(document).find(".page_bg.colorOnly").css("background-color","rgb("+color+")")
$(document).find(".page_bg.colorOnly.dropColor").css("background","linear-gradient(to bottom,rgba("+color+",0.22),rgba("+color+",0))")}else{console.log(err)}})})}else if(window.ui.page.curr().data.becli.single.data.background_color){$(document).find(".page_bg.colorOnly.dropColor").css("background","linear-gradient(to bottom,rgba("+window.ui.page.curr().data.becli.single.data.background_color+",0.22),rgba("+window.ui.page.curr().data.becli.single.data.background_color+",0))")}
$("body #main .content .page_bg.colorOnly.dropColor").css("top",$("body #main .content .page_bg.colorOnly:not(.dropColor)").height()+parseInt($("body #main .content .page_bg.colorOnly:not(.dropColor)").css("top"))+"px")}
if(_page?(_page.object?_page.object=="page":!1):!1){try{if(window.ui.page.curr().data.becli.single.page.classes.includes("_cd_bigslider")){window.theme.pre_designs.hook("bigslider")}
if(window.ui.page.curr().data.becli.single.page.classes.includes("_cd_vs")){window.theme.pre_designs.hook("vertical_slider")}}catch($err){}}
if($(document).find(".widget.desc").length){if($(document).find(".widget.desc .html_wrapper .editorjs_html_wrapper").height()>140)
$(document).find(".widget.desc").addClass("shorten").find(".html_wrapper").append("<div class='shorten_more'>"+window.lang.return("more",{ucfirst:!0})+"</div>")}}else if(_event=="unloading"){window.theme.pre_designs.unhook()}});$(document).on("click",".widget.desc .widget_content .shorten_more",function(){if($(document).find(".widget.desc").hasClass("shorten_opened")){$(document).find(".widget.desc").removeClass("shorten_opened").find(".shorten_more").text(window.lang.return("more",{ucfirst:!0}))}else{$(document).find(".widget.desc").addClass("shorten_opened").find(".shorten_more").text(window.lang.return("less",{ucfirst:!0}))}})
$(document).on("m2_focus_set",function(event,$args){if(!window.app.config.mobile)
return;window.bof._loadExtension({name:"Vibrant",path:"vibrant.min.js",base:"https://cdn.jsdelivr.net/npm/node-vibrant@3.1.5/dist/",dir:"",skipNameCheck:!0,}).done(function(){var path=$args.data.cover
var __mp=0;var color=null;Vibrant.from(path+(path.includes("?bof=")?"":((path.includes("?")?"&":"?")+"bof=dont_cache"))).quality(5).getPalette(function(err,palette){if(!err&&palette){for(var i=0;i<Object.keys(palette).length;i++){var palette_i_key=Object.keys(palette)[i];var pallete_i=palette[palette_i_key];if(pallete_i.population>__mp){__mp=pallete_i.population;color=pallete_i.rgb.join(", ")}}
document.querySelector(':root').style.setProperty('--muse_active_item_color',color);document.querySelector(':root').style.setProperty('--player_bg_dyna',color)}else{console.log(err)}})})});window.theme.settings.init()},settings:{page_size:20,_delete_ok:!1,icons:{profile:"account-circle-outline",security:"lock-outline",two_factor:"shield-check-outline",transactions:"wallet-outline",notifications:"bell-outline",links:"link-variant",sessions:"devices",unsub:"autorenew",wallets:"ethereum",delete:"delete-outline"},links:{facebook:["facebook","https://facebook.com/"],twitter:["icon-x","https://x.com/"],linkedin:["linkedin","https://linkedin.com/in/"],spotify:["spotify","https://open.spotify.com/"],soundcloud:["soundcloud","https://soundcloud.com/"],instagram:["instagram","https://instagram.com/"],vk:["link-variant","https://vk.com/"],website:["web","https://"],tiktok:["icon-tiktok","https://tiktok.com/@"],imdb:["movie-open-outline","https://imdb.com/"],tmdb:["movie-roll","https://themoviedb.org/"]},tx_icons:{deposit:"arrow-down-circle-outline",buy:"shopping-outline",sell:"cash-plus",withdraw:"bank-transfer-out",disperse:"call-split"},w:function($key,$fallback){return window.lang.word($key,$fallback)},esc:function($s){return String($s===null||$s===undefined?"":$s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")},locale:function(){try{return window.app.config.user.language||document.documentElement.lang||"en"}catch(err){return"en"}},toast:function($sta,$text){try{window.app.becli.alert($sta,$text)}catch(err){}},confirm:function($o){var S=window.theme.settings;window.bof_modal.create({class:"st_confirm"+($o.danger?" st_danger":""),title:S.esc($o.title),content:"<p class='st_confirm_t'>"+S.esc($o.text)+"</p>",buttons:[[($o.danger?"btn-danger":"btn-primary"),S.esc($o.button),$o.run]],cancelHook:"cancel"})},empty:function($icon,$title,$text){var S=window.theme.settings;return"<div class='st_empty'><span class='mdi mdi-"+$icon+"'></span><b>"+S.esc($title)+"</b>"+($text?"<p>"+S.esc($text)+"</p>":"")+"</div>"},status:function($form,$text,$type){$form.find(".st_status").text($text||"").attr("data-type",$type||"")},init:function(){var S=window.theme.settings;document.addEventListener("click",S.capture,!0);$(document).on("submit",".st_page .bofForm form",function(e){e.preventDefault();$(this).closest(".bofForm").find("._submit")[0].click()});$(document).on("keydown",".st_page .bofForm form input",function(e){if(e.key!=="Enter"||this.type=="checkbox")return;e.preventDefault();$(this).closest(".bofForm").find("._submit")[0].click()});$(document).on("input change",".st_page .bofForm form",function(e){S.dirty($(this).closest(".bofForm"));S.field_ok($(e.target).closest(".input_wrapper"))});$(document).on("click",".st_page .bofForm .input_wrapper.type_checkbox",function(e){if($(e.target).is("input, a, button"))return;$(this).find("input[type=checkbox]")[0].click()});$(document).on("click",".st_page .st_pw_toggle",function(){var input=$(this).siblings("input");var show=input.attr("type")=="password";input.attr("type",show?"text":"password");$(this).attr("aria-label",S.w(show?"hide_password":"show_password")).find(".mdi").toggleClass("mdi-eye-outline mdi-eye-off-outline")});$(document).on("click",".st_page .st_sess_out",function(){S.sessions.ask($(this).data("sess-id"))});$(document).on("click",".st_page .st_sess_all",function(){S.sessions.ask_all()});$(document).on("click",".st_page .st_more",function(){S.wallet.more()});$(document).on("keydown",".st_pay .pgt, .st_pay .btns_wrapper .btn",function(e){if(e.key!="Enter"&&e.key!=" ")return;e.preventDefault();$(this).trigger("click")});$(document).on("click input change",".st_pay .pgt, .st_pay .is_wrapper .bof_input",function(){setTimeout(S.pay_sync,0)})},capture:function(e){var S=window.theme.settings;var target=$(e.target);var nav=target.closest(".st_page .st_nav a");if(nav.length){if(!nav.hasClass("active")&&$(document).find(".st_page .bofForm.st_dirty").length){e.preventDefault();e.stopPropagation();S.confirm({title:S.w("unsaved_changes"),text:S.w("leave_unsaved"),button:S.w("leave"),run:"window.theme.settings.go("+JSON.stringify(nav.attr("href"))+")"})}
return}
var button=target.closest(".st_page .bofForm ._submit");if(!button.length)return;var form=button.closest(".bofForm");if(form.hasClass("_loading"))return;if(!S.validate(form)){e.preventDefault();e.stopPropagation();return}
if(form.attr("id")=="delete"&&!S._delete_ok){e.preventDefault();e.stopPropagation();S.confirm({title:S.w("delete_account"),text:S.w("delete_confirm_text"),button:S.w("delete_account"),danger:!0,run:"window.theme.settings.delete_go()"});return}
S._delete_ok=!1},go:function($href){window.bof_modal.close();$(document).find(".st_page .bofForm").removeClass("st_dirty");window.ui.link.navigate($href)},delete_go:function(){window.bof_modal.close();window.theme.settings._delete_ok=!0;$(document).find(".st_page .bofForm#delete ._submit")[0].click()},validate:function($form){var S=window.theme.settings;var first=null;$form.find(".input_wrapper").each(function(){var wrap=$(this);if(!wrap.find(".label ._rm").length)return;var empty=!1;if(wrap.hasClass("type_checkbox"))
empty=!wrap.find("input[type=checkbox]").prop("checked");else if(wrap.hasClass("type_bof_file"))
empty=!wrap.find("input.ci").val();else{var input=wrap.find("input.bof_input:not([type=hidden]), textarea.bof_input, select.bof_input").first();empty=input.length&&!$.trim(input.val())}
if(empty){S.field_err(wrap);if(!first)first=wrap}});if(first){first[0].scrollIntoView({block:"center",behavior:"smooth"});first.find("input:not([type=hidden]), textarea, select").first().trigger("focus")}
return!first},field_err:function($wrap){var S=window.theme.settings;$wrap.addClass("st_invalid");if(!$wrap.find(".st_field_err").length)
$wrap.append("<div class='st_field_err'><span class='mdi mdi-alert-circle-outline'></span>"+S.esc(S.w("field_required"))+"</div>");},field_ok:function($wrap){$wrap.removeClass("st_invalid").find(".st_field_err").remove()},tracked:function($form){return $form.closest(".st_settings").length>0&&$form.attr("id")!="delete"},snap:function($form){$form.data("st_snap",$form.find("form").serialize()).removeClass("st_dirty");window.theme.settings.status($form,"")},dirty:function($form){var S=window.theme.settings;if(!S.tracked($form))return;var dirty=$form.find("form").serialize()!==$form.data("st_snap");$form.toggleClass("st_dirty",dirty);if(!$form.hasClass("_loading")&&!$form.hasClass("_failed"))
S.status($form,dirty?S.w("unsaved_changes"):"");},ready:function($page){var S=window.theme.settings;var root=$(document).find("body #main .content .st_page");S.pay_sync();if(!root.length)return;root.find(".st_nav .st_nav_i").each(function(){$(this).find(".st_nav_ic").addClass("mdi-"+(S.icons[$(this).data("tab")]||"cog-outline"))});try{root.find(".st_nav ._"+window.ui.page.curr().data.becli.single.tab).attr("aria-current","page")}catch(err){}
root.find(".bofForm").each(function(){S.form($(this))});root.find(".icon_404.material-symbols-outlined").each(function(){var map={receipt_long:"receipt",sentiment_dissatisfied:"emoticon-sad-outline"};var name=$.trim($(this).text());$(this).text("").removeClass("material-symbols-outlined").addClass("mdi-"+(map[name]||"information-outline"))});root.find(".form_text:not(.st_note)").each(function(){$(this).addClass("st_note").wrapInner("<div class='st_note_b'></div>").prepend("<span class='mdi mdi-"+($(this).hasClass("success")?"check-decagram-outline":"clock-outline")+" st_note_ic'></span>")});if(root.hasClass("st_tab_sessions"))S.sessions.build(root);if(root.hasClass("st_tab_transactions"))S.wallet.build(root);},form:function($form){var S=window.theme.settings;var id=$form.attr("id");if(id=="delete")
$form.find("._submit").text(S.w("delete_account")).removeClass("btn-primary").addClass("btn-danger");else if($form.closest(".st_settings").length)
$form.find("._submit").text(S.w("save_changes"));$form.find("input[type=password]").each(function(){if($(this).siblings(".st_pw_toggle").length)return;$(this).after("<button type='button' class='st_pw_toggle' aria-label='"+S.esc(S.w("show_password"))+"'><span class='mdi mdi-eye-outline'></span></button>")});$form.find(".name_email input[disabled]").attr("readonly",!0).after("<span class='st_lock mdi mdi-lock-outline'></span>");if(id=="security"&&!$form.find(".name_old_password .tip").length)
$form.find(".name_old_password").append("<div class='tip'>"+S.esc(S.w("required_to_save"))+"</div>");if(id=="links"){$form.find(".input_wrapper.type_text").each(function(){var input=$(this).find("input.bof_input");var link=S.links[input.attr("name")];$(this).find(".text_wrapper").addClass("st_has_prefix").prepend("<span class='st_prefix "+(link&&link[0].indexOf("icon-")===0?link[0]:"mdi mdi-"+(link?link[0]:"link-variant"))+"'></span>");if(link&&!input.attr("placeholder"))input.attr("placeholder",link[1]);})}
$form.find(".file_input_wrapper .preview_wrapper").each(function(){if(!$(this).find(".st_ph").length)
$(this).prepend("<span class='st_ph mdi mdi-"+($(this).closest(".name_avatar_id").length?"account-outline":"image-outline")+"'></span>");});if(S.tracked($form)){S.snap($form);$form.find(".file_input_wrapper").each(function(){new MutationObserver(function(){S.dirty($form)}).observe(this,{attributes:!0,attributeFilter:["class"]})})}},sessions:{build:function($root){var S=window.theme.settings;var table=$root.find("#session_list");if(!table.length)return;var rows=[];table.find("tbody tr.session").each(function(){var tr=$(this);var cells=tr.find("td.platform");rows.push({id:tr.find(".del_sess").data("sess-id"),me:tr.hasClass("this"),flag:tr.find("td.country img").attr("src")||null,ip:tr.find("td.ip span").first().text(),platform:cells.eq(0).text(),os:cells.eq(1).text(),browser:cells.eq(2).text(),time:tr.find("td.time_online").text()})});rows.sort(function(a,b){return b.me-a.me});var others=rows.filter(function(r){return!r.me&&r.id}).length;var html="<div class='st_sessions'><div class='st_panel st_list'>";rows.forEach(function(r){var phone=/android|ios|iphone|ipad/i.test(r.os+" "+r.platform);html+="<div class='st_row st_sess"+(r.me?" this":"")+"' data-sess-id='"+S.esc(r.id)+"'>";html+="<span class='st_row_ic mdi mdi-"+(phone?"cellphone":"monitor")+"'></span>";html+="<div class='st_row_main'><div class='st_row_t'><span class='st_cap'>"+S.esc(r.browser)+"</span><span class='st_dot'>·</span><span class='st_cap'>"+S.esc(r.os)+"</span>"+(r.me?"<span class='st_badge'>"+S.esc(S.w("this_device"))+"</span>":"")+"</div>";html+="<div class='st_row_s'>"+(r.flag?"<img class='st_flag' src='"+S.esc(r.flag)+"' alt=''>":"")+"<span class='st_ip'>"+S.esc(r.ip)+"</span><span class='st_dot'>·</span><span class='st_cap'>"+S.esc(r.platform)+"</span><span class='st_dot'>·</span><span>"+(r.me?S.esc(S.w("active_now")):S.esc(S.w("last_seen"))+": "+S.esc(r.time.toLowerCase()))+"</span></div></div>";if(!r.me&&r.id)
html+="<button type='button' class='btn btn-secondary btn-sm st_sess_out' data-sess-id='"+S.esc(r.id)+"'>"+S.esc(S.w("sign_out"))+"</button>";html+="</div>"});html+="</div>";if(others)
html+="<div class='st_list_foot'><button type='button' class='btn btn-secondary st_sess_all'><span class='mdi mdi-logout'></span>"+S.esc(S.w("sign_out_others"))+"</button></div>";html+="</div>";table.addClass("st_hidden").after(html)},ask:function($id){var S=window.theme.settings;S.confirm({title:S.w("sign_out"),text:S.w("sign_out_confirm"),button:S.w("sign_out"),danger:!0,run:"window.theme.settings.sessions.out("+JSON.stringify(String($id))+")"})},ask_all:function(){var S=window.theme.settings;S.confirm({title:S.w("sign_out_others"),text:S.w("sign_out_others_confirm"),button:S.w("sign_out"),danger:!0,run:"window.theme.settings.sessions.out_all()"})},send:function($id,$cb){window.becli.exe({endpoint:"user_edit?tab=sessions&action=submit",post:{id:$id},callBack:function(sta,data){$cb(sta,data)}})},out:function($id){var S=window.theme.settings;window.bof_modal.set_loading("button");S.sessions.send($id,function(sta,data){window.bof_modal.close();if(!sta){S.toast(!1,data&&data.messages?data.messages[0]:"?");return}
var row=$(document).find(".st_sess[data-sess-id='"+$id+"']").addClass("st_gone");setTimeout(function(){row.remove();if(!$(document).find(".st_sess:not(.this)").length)$(document).find(".st_sess_all").closest(".st_list_foot").remove();},250);S.toast(!0,S.w("signed_out"))})},out_all:function(){var S=window.theme.settings;var ids=$(document).find(".st_sess:not(.this)").map(function(){return $(this).data("sess-id")}).get();window.bof_modal.set_loading("button");var next=function(){if(!ids.length){window.bof_modal.close();S.toast(!0,S.w("signed_out"));window.ui.page.reload();return}
S.sessions.send(ids.shift(),next)};next()}},wallet:{items:[],shown:0,build:function($root){var S=window.theme.settings;var W=S.wallet;var content=window.ui.page.curr().data.becli.single.content;if(!content||!$.isArray(content.items))return;W.items=content.items.slice().sort(function(a,b){return(b.time||0)-(a.time||0)});W.shown=0;var withdraw=!1;try{withdraw=!!window.app.config.user.extra.roles.withdraw}catch(err){}
var html="<div class='st_wallet'>";html+="<div class='st_panel st_balance'><div class='st_balance_l'><span class='st_k'>"+S.esc(S.w("your_funds"))+"</span><b class='st_balance_v'>"+S.esc(content.funds)+"</b></div><div class='st_balance_a'>";html+="<a class='btn btn-primary' href='user_pay'><span class='mdi mdi-plus'></span>"+S.esc(S.w("add_funds"))+"</a>";if(withdraw)html+="<a class='btn btn-secondary' href='user_withdrawal'><span class='mdi mdi-bank-transfer-out'></span>"+S.esc(S.w("withdrawal"))+"</a>";html+="</div></div>";if(W.items.length)
html+="<div class='st_panel st_list st_ledger'></div><div class='st_list_foot'><button type='button' class='btn btn-secondary st_more'>"+S.esc(S.w("show_more"))+"</button></div>";else html+=S.empty("receipt",S.w("no_transactions"));html+="</div>";$root.find(".st_content .transactions").addClass("st_hidden").after(html);W.more()},more:function(){var S=window.theme.settings;var W=S.wallet;var next=W.items.slice(W.shown,W.shown+S.page_size);var last=W.shown?W.items[W.shown-1]:null;var html="";next.forEach(function(item){var month=W.month(item.time);if(month&&(!last||W.month(last.time)!==month))html+="<div class='st_month'>"+S.esc(month)+"</div>";html+=W.row(item);last=item});$(document).find(".st_ledger").append(html);W.shown+=next.length;$(document).find(".st_more").closest(".st_list_foot").toggle(W.shown<W.items.length)},row:function($item){var S=window.theme.settings;var W=S.wallet;var title=$item.title||$item.object_label||$item.type_label;var sub=[];if($item.type_label&&$item.type_label!==title)sub.push($item.type_label);if($item.title&&$item.object_label)sub.push($item.object_label);if($item.time)sub.push(W.date($item.time));var icon=$item.cover?"<span class='st_tx_cover' style='background-image:url(\""+S.esc($item.cover)+"\")'></span>":"<span class='st_row_ic mdi mdi-"+(S.tx_icons[$item.type]||"swap-horizontal")+"'></span>";return"<div class='st_row st_tx "+($item.amount>0?"_in":"_out")+"'>"+icon+"<div class='st_row_main'><div class='st_row_t'>"+S.esc(title)+"</div><div class='st_row_s'>"+sub.map(S.esc).join("<span class='st_dot'>·</span>")+"</div></div>"+"<div class='st_tx_amt'>"+W.amount($item)+"</div></div>"},amount:function($item){var S=window.theme.settings;var n=Math.abs($item.amount);var s=String(n);try{s=new Intl.NumberFormat(S.locale(),{minimumFractionDigits:2,maximumFractionDigits:8}).format(n)}catch(err){}
return"<b>"+($item.amount>0?"+":($item.amount<0?"−":""))+S.esc(s)+"</b> <span>"+S.esc($item.currency||"")+"</span>"},date:function($time){try{return new Intl.DateTimeFormat(window.theme.settings.locale(),{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"}).format(new Date($time*1000))}catch(err){return""}},month:function($time){if(!$time)return"";try{return new Intl.DateTimeFormat(window.theme.settings.locale(),{month:"long",year:"numeric"}).format(new Date($time*1000))}catch(err){return""}}},pay_sync:function(){$(document).find(".st_pay").each(function(){var pay=$(this);pay.find(".pgt").each(function(){$(this).attr("aria-checked",$(this).hasClass("selected")?"true":"false")});var value=parseFloat(pay.find(".is_wrapper .bof_input").val());var symbol="";try{symbol=window.app.pages.user_pay.currency_data.symbol||""}catch(err){}
pay.find(".st_sum_amount").text(value?value+" "+symbol:"?")})}},bofForm:{_form:function($ID){var form=$(document).find("#"+$ID+".bofForm");return form.closest(".st_page").length?form:null},loading:function($ID){var form=window.theme.bofForm._form($ID);if(!form)return!1;form.removeClass("_failed _done").addClass("_loading").attr("aria-busy","true");form.find("._error").removeClass("ok").empty();form.find("._submit").attr("aria-disabled","true");return!0},done:function($ID,$args,$result){var S=window.theme.settings;var form=window.theme.bofForm._form($ID);if(!form)return!1;var message=$result&&$result.messages?$result.messages[0]:"";form.removeClass("_loading _failed").addClass("_done").removeAttr("aria-busy");form.find("._submit").removeAttr("aria-disabled");setTimeout(function(){form.removeClass("_done")},2500);if($ID=="delete"){S.toast(!0,message);window.app.actions.user.logout();return!0}
if(form.closest(".st_settings").length){if($ID=="security")form.find("input[type=password]").val("");S.snap(form);S.toast(!0,S.w("changes_saved"));return!0}
S.toast(!0,message);if(form.closest(".st_tab_withdrawal").length){form.find("form")[0].reset();S.status(form,message,"ok")}else{window.ui.page.reload()}
return!0},failed:function($ID,$args,$result){var form=window.theme.bofForm._form($ID);if(!form)return!1;var message=$result&&$result.messages&&$result.messages[0]?$result.messages[0]:"?";form.removeClass("_loading _done").addClass("_failed").removeAttr("aria-busy");form.find("._submit").removeAttr("aria-disabled");form.find("._error").html("<span class='mdi mdi-alert-circle-outline'></span><span class='st_err_t'>"+message+"</span>");window.theme.settings.status(form,"");return!0}},pre_designs:{active:null,hook:function($name){window.theme.pre_designs.active=$name;window.theme.pre_designs[$name].hook()},unhook:function(){if(window.theme.pre_designs.active){window.theme.pre_designs[window.theme.pre_designs.active].unhook();window.theme.pre_designs.active=null}},bigslider:{timer:null,timer2:null,i:null,total:3,hook:function(){this.total=$(document).find("body._cd_bigslider.object_n_page .grid.i0 .cols_4_4_4 .col .widget").length;this.startSliding(!0);$(window).off('.themeBigSlider');$(window).on('blur.themeBigSlider',function(){var slider=window.theme.pre_designs.bigslider;clearTimeout(slider.timer);clearTimeout(slider.timer2);slider.timer=null;slider.timer2=null});$(window).on('focus.themeBigSlider',function(){window.theme.pre_designs.bigslider.startSliding()})},startSliding:function($ini){if($ini){this.i=this.total}
var newId=(this.i%this.total)+1;if(!$ini)
this.slideOut($(document).find("body._cd_bigslider.object_n_page .grid.i0 .cols_4_4_4 .col.active"));if(this.timer2)
clearTimeout(window.theme.pre_designs.bigslider.timer2);this.timer2=setTimeout(function(){try{window.theme.pre_designs.bigslider.slideIn($(document).find("body._cd_bigslider.object_n_page .grid.i0 .cols_4_4_4 .col:nth-child("+newId+")"))}catch(err){}},230);if(this.timer)
clearTimeout(window.theme.pre_designs.bigslider.timer);this.timer=setTimeout(function(){window.theme.pre_designs.bigslider.startSliding()},6000);this.i=this.i+1},slideIn:function($dom){$dom.addClass("active");if(!$dom.hasClass("ted")){$(document).find("body._cd_bigslider.object_n_page .grid.i0 .cols_4_4_4 .col.active .html_wrapper .title")
var _ted=$dom.find(".html_wrapper .title").text().split(" ");$dom.find(".html_wrapper .title").html("<b>"+_ted[0]+"</b> "+(_ted.length>1?_ted.slice(1).join(" "):""));$dom.addClass("ted")}
$dom.fadeIn(200)},slideOut:async function($dom){await $dom.fadeOut(200).promise();$dom.removeClass("active")},unhook:function(){try{clearTimeout(window.theme.pre_designs.bigslider.timer);clearTimeout(window.theme.pre_designs.bigslider.timer2);this.timer=null;this.timer2=null;$(window).off('.themeBigSlider')}catch($err){}}},vertical_slider:{active:null,total:null,moving:!1,touchY:!1,touchF:!1,timer:!1,hook:function(){this.active=0;this.total=$(document).find("#main .content .widget").length;$(document).find(".widget.i0").addClass("vs_active");this._createBullets();$(document).find("body._cd_vs .vs_bullets_wrapper .vs_bullet_wrapper.i0").addClass("vs_bullet_active");window.theme.pre_designs.vertical_slider._resetTimer();$("#main").bind('mousewheel DOMMouseScroll',function(e){var delta=Math.max(-1,Math.min(1,(e.wheelDelta||-e.detail)));var direction=(e.originalEvent.deltaY>0)?"up":"down";window.theme.pre_designs.vertical_slider._direct(direction);return!1});$("#main").bind('touchmove',function(e){if(window.theme.pre_designs.vertical_slider.touchY){if(!window.theme.pre_designs.vertical_slider.touchF){window.theme.pre_designs.vertical_slider.touchF=!0;var direction=window.theme.pre_designs.vertical_slider.touchY-e.originalEvent.touches[0].screenY>0?"up":"down";window.theme.pre_designs.vertical_slider._direct(direction)}}else{window.theme.pre_designs.vertical_slider.touchY=e.originalEvent.touches[0].screenY}});$("#main").bind('touchend',function(e){window.theme.pre_designs.vertical_slider.touchY=null;window.theme.pre_designs.vertical_slider.touchF=!1});$(document).on("click","body._cd_vs .vs_bullets_wrapper .vs_bullet_wrapper",function(){var target=$(this).data("i")
if(target==window.theme.pre_designs.vertical_slider.active)return;window.theme.pre_designs.vertical_slider._position(target,target>window.theme.pre_designs.vertical_slider.active?"bottom":"top")
window.theme.pre_designs.vertical_slider._enter(target,target>window.theme.pre_designs.vertical_slider.active?"bottom":"top")})},unhook:function(){$("#main").unbind('mousewheel DOMMouseScroll');$("#main").unbind('touchmove');$("#main").unbind('touchend');$(document).off("click","body._cd_vs .vs_bullets_wrapper .vs_bullet_wrapper");try{clearTimeout(this.timer)}catch($err){}},_direct:function(_dir){if(_dir=="up")
this._next();else this._prev()},_prev:function(){if(this.moving||this.active==0)
return;this._position(this.active-1,"top")
this._enter(this.active-1,"top")},_next:function(){var target=this.active+1;if(this.moving)
return;if(target>=this.total)
target=0;this._position(target,"bottom")
this._enter(target,"bottom")},_position:function($targetI,$position){var $targetDom=$(document).find(".widget.i"+$targetI);$targetDom.removeClass("vs_onTop").removeClass("vs_onBottom").addClass($position=="top"?"vs_onTop":"vs_onBottom")},_enter:function($targetI,$from){var $targetDom=$(document).find(".widget.i"+$targetI);this.moving=!0;$(document).find(".widget.vs_active").removeClass("vs_active").addClass("vs_pre_active")
$targetDom.removeClass("vs_still").addClass("vs_moving");$(document).find(".vs_pre_active .widget_content").fadeOut({queue:!1,duration:300});setTimeout(function(){if($from=="bottom")$targetDom.animate({top:0},600);else $targetDom.animate({top:0},600);window.theme.pre_designs.vertical_slider._updateBullets($targetI);setTimeout(function(){$targetDom.find(".widget_content").fadeIn({queue:!1,duration:300});$targetDom.find(".widget_content .html_wrapper").css("top","-40px");$targetDom.find(".widget_content .html_wrapper").animate({top:"0"},300);setTimeout(function(){window.theme.pre_designs.vertical_slider.moving=!1;window.theme.pre_designs.vertical_slider.active=$targetI;$targetDom.removeClass("vs_moving").removeClass("vs_onBottom").removeClass("vs_onTop").addClass("vs_active");$(document).find(".vs_pre_active .widget_content").css("display","");$(document).find(".vs_pre_active").removeClass("vs_pre_active").css("top","").css("bottom","").addClass("vs_onTop")
window.theme.pre_designs.vertical_slider._resetTimer()},300)},500)},250)},_createBullets:function(){if(!this.total)return;var bulletsHTML="<div class='vs_bullets_wrapper'>";for(var i=0;i<this.total;i++)
bulletsHTML+="<div class='vs_bullet_wrapper i"+i+"' data-i='"+i+"'></div>";bulletsHTML+="</div>";$(document).find("#main .content").append(bulletsHTML)},_updateBullets:function(i){$(document).find("body._cd_vs .vs_bullets_wrapper .vs_bullet_wrapper.vs_bullet_active").removeClass("vs_bullet_active");$(document).find("body._cd_vs .vs_bullets_wrapper .vs_bullet_wrapper.i"+i).addClass("vs_bullet_active")},_resetTimer:function(){try{clearTimeout(this.timer)}catch($err){}
this.timer=setTimeout(function(){window.theme.pre_designs.vertical_slider._next()},7*1000)}}},getIcons:function(){return this.icons},dicon:function($name,$args){$args=$args?$args:{};var $raw=$args.raw?!0:!1;var $class=$args.class?$args.class:"";var $val=$raw?$name:window.config.display.icon($name);return"<span class='mdi "+$class+" mdi-"+$val+"'></span>"},iconSetName:"MDI",icons:{airplane:"airplane-takeoff",airplane_off:"airplane-landing",happy:"robot-happy-outline",sad:"robot-dead-outline",close:"close",refresh:"refresh",alert:"alert-circle-outline",loading:"loading",pending:"reload",paused:"pause-circle-outline",downloading:"tray-arrow-down",done:"check-circle-outline",failed:"alert-circle-outline",download:"download",pause:"pause",delete:"delete",downloads:"wifi-off",playlist_create:"plus-circle-outline",play:"play",like:"heart",play_next:"playlist-music",play_last:"playlist-music-outline",playlist:"playlist-plus",share:"share",open:"open-in-app",back:"keyboard-backspace",up_podcast:"podcast",cast:"cast",chevron:"chevron-right",chevron_up:"chevron-up",chevron_down:"chevron-down",back:"arrow-left",close:"close-circle-outline",cancel:"close",dots:"dots-vertical",cog:"cog-outline",tune_variant:"tune-variant",play:"play",pause:"pause",loading:"refresh",refresh:"refresh",prev:"skip-previous",next:"skip-next",speed:"play-speed",shuffle:"shuffle",repeat:"repeat",repeat_off:"repeat-off",infinite:"infinity",all_inclusive:"all-inclusive",heart_outline:"heart-outline",heart_filled:"heart",volume:"volume-high",volume_high:"volume-high",volume_off:"volume-off",fullscreen:"fullscreen",fit:"aspect-ratio",subtitles:"subtitles",quality:"tune",lock:"lock",arrow_next:"chevron-right",upload:"cloud-upload",u_pending:"progress-clock",u_processing:"refresh",u_done:"progress-check",u_failed:"progress-alert",swap_sort:"swap_vert",}}
window.theme.run()
;
/* ===== Mobile mini-player: card content (logo, title, arrow) follows the finger upwards while pulling the player open =====
   Visual only. Passive listeners, nothing is cancelled, the site's own open/close logic is not touched.
   Soft, floating feel: eased follow, slight shrink + deeper shadow, slow fade, faint blue halo, gentle settle. */
(function(){
  "use strict";
  var st = null, ghost = null, raf = 0, cur = 0, tgt = 0, OFF = "pl_ghost_on";
  var FOLLOW = 0.2;      /* 0..1  smaller = softer / more lag behind the finger */
  var SHRINK = 0.05;     /* max shrink of the card while lifted (5%)            */
  var STOP_AT = 0.56;    /* where the card ends (and has fully faded): 0 = top of screen, 0.5 = middle, 0.56 = a little below the middle */
  var FADE_DIST = 380;   /* px of travel until the card has fully faded  (recalculated from STOP_AT for every pull) */
  var HALO_DIST = 260;   /* px of travel until the blue halo has faded away (recalculated for every pull) */
  var MAXT = 380;        /* the card never travels further up than this (px)    */
  function body(){ return document.body }
  function isMobile(){ var b = body(); return !!b && b.classList.contains("mobile") }
  function cleanup(){
    if ( raf ) cancelAnimationFrame( raf ); raf = 0;
    if ( ghost && ghost.parentNode ) ghost.parentNode.removeChild( ghost );
    ghost = null; cur = 0; tgt = 0;
    if ( body() ) body().classList.remove( OFF );
    st = null;
  }
  function place( src, host, box, extra ){
    var r = src.getBoundingClientRect(), c = src.cloneNode( true );
    c.removeAttribute( "id" );
    c.style.cssText = "position:absolute;margin:0;box-sizing:border-box;left:" + ( r.left - box.left ) + "px;top:" + ( r.top - box.top ) + "px;width:" + r.width + "px;height:" + r.height + "px;" + ( extra || "" );
    host.appendChild( c );
  }
  function build(){
    var p = document.getElementById( "player" );
    if ( !p ) return false;
    var box = p.getBoundingClientRect();
    if ( !box.height || !box.width ) return false;
    /* travel distance = from the card's centre up to STOP_AT of the screen height */
    var vh = window.innerHeight || document.documentElement.clientHeight || 700;
    MAXT = Math.max( 160, ( box.top + box.height / 2 ) - vh * STOP_AT );
    FADE_DIST = MAXT; HALO_DIST = MAXT * 0.7;
    var g = document.createElement( "div" );
    g.id = "pl_ghost";
    g.style.cssText = "left:" + box.left + "px;top:" + box.top + "px;width:" + box.width + "px;height:" + box.height + "px;background-color:" + ( getComputedStyle( p ).backgroundColor || "#111" );
    var d = p.querySelector( ".data_wrapper" ), pl = p.querySelector( ".controls_wrapper .control.play" );
    if ( d ) place( d, g, box );
    if ( pl ) place( pl, g, box, "text-align:center;opacity:.9;" );
    g.style.visibility = "hidden";
    document.body.appendChild( g );
    ghost = g;
    return true;
  }
  function paint( dy ){
    if ( !ghost ) return;
    var a = Math.abs( dy ), t = Math.min( 1, a / HALO_DIST );
    var s = 1 - SHRINK * Math.min( 1, a / 120 );
    var fade = Math.max( 0, 1 - Math.pow( Math.min( 1, a / FADE_DIST ), 1.35 ) );
    var halo = Math.min( 1, a / 18 ) * Math.pow( 1 - t, 1.2 );   /* ramps in, then fades the higher it goes */
    ghost.style.transform = "translate3d(0," + dy + "px,0) scale(" + s + ")";
    ghost.style.opacity = fade;
    ghost.style.setProperty( "--pl-halo", halo.toFixed( 3 ) );
    ghost.style.setProperty( "--pl-lift", Math.min( 1, a / 120 ).toFixed( 3 ) );
  }
  function loop(){
    raf = 0;
    if ( !ghost || !st || !st.on ) return;
    cur += ( tgt - cur ) * FOLLOW;
    if ( Math.abs( tgt - cur ) < 0.2 ) cur = tgt;
    paint( cur );
    raf = requestAnimationFrame( loop );
  }
  function start( e ){
    if ( !isMobile() || !e.touches || e.touches.length !== 1 ) return;
    cleanup();
    var b = body();
    if ( b.classList.contains( "que_active" ) || b.classList.contains( "que_active_open" ) ) return;
    var p = document.getElementById( "player" );
    if ( !p ) return;
    var r = p.getBoundingClientRect(), tx = e.touches[0].clientX, ty = e.touches[0].clientY;
    /* hit-test by the card's rectangle (an invisible overlay may be the real touch target) */
    if ( !r.height || tx < r.left || tx > r.right || ty < r.top || ty > r.bottom ) return;
    /* snapshot the card NOW, before the site's own pull logic restyles it */
    if ( !build() ) return;
    st = { x: tx, y: ty, on: false };
  }
  function move( e ){
    if ( !st || !e.touches || !e.touches.length ) return;
    var dx = e.touches[0].clientX - st.x, dy = e.touches[0].clientY - st.y;
    if ( !st.on ){
      if ( dy > -6 || Math.abs( dy ) < Math.abs( dx ) ){ return }
      if ( !ghost ){ st = null; return }
      ghost.style.visibility = "visible";
      body().classList.add( OFF );
      st.on = true; cur = 0;
    }
    tgt = Math.max( -MAXT, Math.min( 0, dy ) );   /* stops at the fade point, never goes higher */
    if ( !raf ) raf = requestAnimationFrame( loop );
  }
  function end(){
    if ( !st ) return;
    if ( !st.on || !ghost ){ cleanup(); return }
    var g = ghost, back = Math.abs( tgt ) < 40;
    st.on = false;
    if ( raf ) cancelAnimationFrame( raf ); raf = 0;
    if ( back ){
      /* not pulled far enough: settle gently back into place */
      g.style.transition = "transform 420ms cubic-bezier(.22,1,.36,1), opacity 320ms ease-out";
      g.style.setProperty( "--pl-halo", "0" ); g.style.setProperty( "--pl-lift", "0" );
      g.style.transform = "translate3d(0,0,0) scale(1)"; g.style.opacity = 1;
      setTimeout( function(){ if ( ghost === g ) cleanup() }, 440 );
    } else {
      /* the panel opens: keep drifting up while dissolving */
      g.style.transition = "transform 380ms cubic-bezier(.2,.7,.3,1), opacity 340ms ease-out";
      g.style.transform = "translate3d(0," + Math.max( -MAXT, cur - 28 ) + "px,0) scale(" + ( 1 - SHRINK - 0.01 ) + ")";
      g.style.opacity = 0;
      g.style.setProperty( "--pl-halo", "0" );
      setTimeout( function(){ if ( ghost === g ) cleanup() }, 400 );
    }
  }
  var o = { passive: true, capture: true };
  document.addEventListener( "touchstart", start, o );
  document.addEventListener( "touchmove", move, o );
  document.addEventListener( "touchend", end, o );
  document.addEventListener( "touchcancel", end, o );
})();

;
/* ===== Mobile loading screen ( TuneFa ) =====
   Shown ONCE on every open / refresh of the site and kept for HOLD_MS ( 4 s ), no matter how fast the site is ready.
   If the site is still loading after HOLD_MS the screen waits for it ( up to MAX_MS ).
   Visual only: the site's own loading logic is not touched, nothing is cancelled, no events are stolen.
   Without this script the plain CSS fallback in 15_mobile.css ( dark screen + spinning ring ) is shown.
   Brand texts can be changed in the three variables below. */
(function(){
  "use strict";
  var BRAND_A  = "Tune";            /* white part of the name   */
  var BRAND_B  = "FA";              /* blue part of the name    */
  var TAGLINE  = "Feel The Music";
  var HOLD_MS  = 4000;              /* the screen stays this long on every open / refresh ( ms ) */
  var MAX_MS   = 20000;             /* safety: never stay longer than this, even if the site keeps "loading" */
  var HIDE_MS  = 760;               /* keep animations alive this long while the screen fades out */

  var el = null, started = false, minDone = false, maxed = false, hidden = false, obs = null;

  function esc( s ){ return String( s ).replace( /[&<>"]/g, function( c ){ return { "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;" }[ c ] } ) }
  function rnd( i, k ){ return ( ( i * 37 + k * 11 ) % 17 ) / 16 }          /* stable pseudo random 0..1 */

  function sideBars( n, flip ){
    var o = "", i, r, h, d, t;
    for ( i = 0; i < n; i++ ){
      r = flip ? ( n - 1 - i ) : i;                                         /* r = 0 outer ... n-1 inner */
      h = 12 + Math.round( ( 0.35 + 0.65 * Math.sin( ( r / ( n - 1 ) ) * Math.PI * 0.85 + 0.2 ) ) * rnd( i, 3 ) * 52 );
      d = -( rnd( i, 5 ) * 2.4 ).toFixed( 2 );
      t = ( 1.5 + rnd( i, 7 ) * 1.3 ).toFixed( 2 );
      o += '<b style="--h:' + h + 'px;--d:' + d + 's;--t:' + t + 's"></b>';
    }
    return o;
  }

  function bottomBars( n ){
    var o = "", i, c = ( n - 1 ) / 2, h;
    for ( i = 0; i < n; i++ ){
      h = 9 + Math.round( 36 * Math.exp( -Math.pow( ( i - c ) / ( n / 3.4 ), 2 ) ) );
      o += '<b style="--h:' + h + 'px;--i:' + i + '"></b>';
    }
    return o;
  }

  var NOTE1 = "M12,3V13.55C11.41,13.21 10.73,13 10,13C7.79,13 6,14.79 6,17C6,19.21 7.79,21 10,21C12.21,21 14,19.21 14,17V7H18V3H12Z";

  function html(){
    return '' +
    '<div class="tf_bg">' +
      '<i class="tf_blob b1"></i><i class="tf_blob b2"></i><i class="tf_blob b3"></i>' +
      '<svg class="tf_wave w1" viewBox="0 0 400 800" preserveAspectRatio="xMinYMin slice" focusable="false">' +
        '<defs><linearGradient id="tfwA" x1="1" y1="0" x2="0" y2="1"><stop offset="0" class="s1" stop-opacity="0"/><stop offset=".45" class="s1" stop-opacity=".95"/><stop offset="1" class="s2" stop-opacity=".1"/></linearGradient></defs>' +
        '<path class="f" d="M0,0H196C150,52 96,62 52,92C22,112 6,140 0,176Z"/>' +
        '<path class="g" d="M196,0C150,52 96,62 52,92C22,112 6,140 0,176" />' +
        '<path class="l" d="M196,0C150,52 96,62 52,92C22,112 6,140 0,176" stroke="url(#tfwA)"/>' +
        '<path class="l t" d="M262,0C206,70 128,70 74,108C34,136 12,176 0,226" stroke="url(#tfwA)"/>' +
      '</svg>' +
      '<svg class="tf_wave w2" viewBox="0 0 400 800" preserveAspectRatio="xMaxYMax slice" focusable="false">' +
        '<defs><linearGradient id="tfwB" x1="0" y1="1" x2="1" y2="0"><stop offset="0" class="s1" stop-opacity="0"/><stop offset=".5" class="s1" stop-opacity=".95"/><stop offset="1" class="s2" stop-opacity=".1"/></linearGradient></defs>' +
        '<path class="f" d="M400,800V652C342,656 292,690 242,728C202,758 160,778 112,800Z"/>' +
        '<path class="g" d="M112,800C160,778 202,758 242,728C292,690 342,656 400,652" />' +
        '<path class="l" d="M112,800C160,778 202,758 242,728C292,690 342,656 400,652" stroke="url(#tfwB)"/>' +
        '<path class="l t" d="M40,800C120,790 190,742 246,700C300,662 352,626 400,618" stroke="url(#tfwB)"/>' +
      '</svg>' +
      '<i class="tf_grain"></i>' +
    '</div>' +
    '<svg class="tf_note n1" viewBox="0 0 24 24" focusable="false"><path d="' + NOTE1 + '"/></svg>' +
    '<svg class="tf_note n2" viewBox="0 0 24 24" focusable="false"><path d="' + NOTE1 + '"/></svg>' +
    '<svg class="tf_note n3" viewBox="0 0 24 24" focusable="false"><path d="' + NOTE1 + '"/></svg>' +
    '<div class="tf_stage">' +
      '<div class="tf_row">' +
        '<div class="tf_eq l">' + sideBars( 15, false ) + '</div>' +
        '<div class="tf_ring">' +
          '<i class="tf_glow"></i><i class="tf_rip r1"></i><i class="tf_rip r2"></i>' +
          '<i class="tf_track"></i><i class="tf_arc"></i>' +
          '<b class="tf_icon"></b>' +
        '</div>' +
        '<div class="tf_eq r">' + sideBars( 15, true ) + '</div>' +
      '</div>' +
      '<div class="tf_brand"><span class="a">' + esc( BRAND_A ) + '</span><span class="b">' + esc( BRAND_B ) + '</span></div>' +
      '<div class="tf_tag">' + esc( TAGLINE ) + '</div>' +
      '<div class="tf_bars"><div class="eq">' + bottomBars( 13 ) + '</div></div>' +
    '</div>';
  }

  function build(){
    if ( el || !document.body ) return;
    el = document.createElement( "div" );
    el.id = "tf_splash";
    el.setAttribute( "aria-hidden", "true" );
    el.innerHTML = html();
    document.body.appendChild( el );
    document.documentElement.classList.add( "tf_sp" );       /* CSS fallback ring steps aside */
  }

  function check(){
    if ( !started || hidden || !minDone || !el ) return;
    if ( !maxed && document.body.classList.contains( "loading" ) ) return;   /* site still not ready: wait */
    hidden = true;
    el.classList.remove( "tf_show" );
    setTimeout( function(){ if ( el ) el.classList.remove( "tf_run" ) }, HIDE_MS );
  }

  function start(){
    var b = document.body;
    if ( started || !b || !b.classList.contains( "mobile" ) ) return;
    build();
    if ( !el ) return;
    started = true;
    el.style.bottom = "0";
    el.classList.add( "tf_run" );
    void el.offsetWidth;                                      /* restart the entrance animation */
    el.classList.add( "tf_show" );
    setTimeout( function(){ minDone = true; check() }, HOLD_MS );
    setTimeout( function(){ minDone = true; maxed = true; check() }, MAX_MS );
  }

  function sync(){ start(); check() }

  function init(){
    if ( !document.body ) return;
    sync();
    if ( window.MutationObserver ){
      obs = new MutationObserver( sync );
      obs.observe( document.body, { attributes: true, attributeFilter: [ "class" ] } );
    } else {
      setInterval( sync, 200 );
    }
  }

  if ( document.body ) init();
  else document.addEventListener( "DOMContentLoaded", init );
})();

;
/* ===== Messages ( chat ) page: no loading cover when sending a message / switching chats / opening the chat =====
   1. html.tf_quiet  : switches the site's own body.loading cover off while the chat is involved ( CSS in 15_mobile.css ).
   2. .tf_nocover / .tf_nopseudo : whatever big opaque cover ( a box, or a ::before / ::after layer ) is found on top of the chat is made invisible.
   Visual only: nothing is cancelled and the site's own logic keeps running. */
(function(){
  "use strict";
  var RX = /\/messe/i;                       /* path of the messages page ( /messenger, /messages ... ) */
  var lastHref = "", lastT = 0, root = document.documentElement;
  function msgUrl( u ){ try { return RX.test( new URL( u, location.href ).pathname ) } catch( e ){ return false } }
  function inChat(){ return msgUrl( location.href ) || !!document.getElementById( "messenger" ) }
  function realLink( h ){ return !!h && h.charAt( 0 ) !== "#" && h.indexOf( "javascript" ) !== 0 }

  document.addEventListener( "click", function( e ){
    var a = e.target && e.target.closest ? e.target.closest( "a[href]" ) : null;
    lastHref = a ? a.getAttribute( "href" ) : ""; lastT = Date.now();
  }, true );

  function quiet(){
    var b = document.body;
    if ( !b ) return;
    var ld = b.classList.contains( "loading" ) && !b.classList.contains( "splash" );
    if ( !ld ){ root.classList.remove( "tf_quiet" ); return }
    var q;
    if ( Date.now() - lastT < 1500 && realLink( lastHref ) ) q = msgUrl( lastHref );   /* a link was tapped: its target decides */
    else q = inChat();                                                                  /* send button, chat switch ... */
    root.classList.toggle( "tf_quiet", q );
  }

  function alpha( c ){
    var m = /rgba?\(([^)]+)\)/.exec( c || "" ); if ( !m ) return 0;
    var p = m[1].split( "," ); return p.length > 3 ? parseFloat( p[3] ) : 1;
  }
  var SKIP = "#main,#messenger,.content,.main_content,#tf_splash,#player,.sidebar_fl,.navbar";
  function bigBox( r ){ return r.width * r.height >= 0.35 * window.innerWidth * window.innerHeight }
  function pseudoCover( n, p ){
    var cs = getComputedStyle( n, p );
    if ( !cs || cs.content === "none" || cs.content === "normal" || cs.display === "none" ) return false;
    if ( cs.position !== "fixed" && cs.position !== "absolute" ) return false;
    if ( parseFloat( cs.width ) * parseFloat( cs.height ) < 0.35 * window.innerWidth * window.innerHeight ) return false;
    return alpha( cs.backgroundColor ) > 0.3 || ( cs.backgroundImage && cs.backgroundImage !== "none" );
  }
  /* look at what is really on top of the chat ( 3 points ) and switch off every big opaque cover found there: a box, or a ::before / ::after layer */
  function cover(){
    var vw = window.innerWidth, vh = window.innerHeight, ys = [ 0.3, 0.5, 0.65 ], i, n, cs, e;
    for ( i = 0; i < ys.length; i++ ){
      e = document.elementFromPoint( vw * 0.5, vh * ys[ i ] );
      if ( e && e.closest && e.closest( "#tf_splash" ) ) continue;
      for ( n = e; n && n !== document.body && n !== document.documentElement; n = n.parentElement ){
        if ( n.id === "tf_splash" ) break;
        if ( !n.matches( SKIP ) && !n.classList.contains( "tf_nocover" ) ){
          cs = getComputedStyle( n );
          if ( bigBox( n.getBoundingClientRect() ) && alpha( cs.backgroundColor ) > 0.3 && !n.textContent.trim() && !n.querySelector( "input,textarea,img,video,canvas,.bof_input" ) ){
            n.classList.add( "tf_nocover" ); break;
          }
        }
        if ( !n.classList.contains( "tf_nopseudo" ) && ( pseudoCover( n, "::before" ) || pseudoCover( n, "::after" ) ) ) n.classList.add( "tf_nopseudo" );
      }
    }
  }
  function clean(){
    var l = document.querySelectorAll( ".tf_nocover,.tf_nopseudo" ), i;
    for ( i = 0; i < l.length; i++ ) l[ i ].classList.remove( "tf_nocover", "tf_nopseudo" );
  }
  function run(){ quiet(); if ( inChat() ) cover(); else clean() }

  function init(){
    if ( !document.body ) return;
    run();
    if ( window.MutationObserver ) new MutationObserver( run ).observe( document.body, { childList: true, subtree: true, attributes: true, attributeFilter: [ "class", "style" ] } );
    setInterval( run, 150 );                                  /* backup: catches covers that appear without a DOM change */
  }
  if ( document.body ) init(); else document.addEventListener( "DOMContentLoaded", init );
})();
;
/* ===== Messages ( chat ) page: top bar look ( class only ) =====
   Gives the visible top bar of an open chat ( the full-width strip at the top that holds the "@name" and the avatars )
   the class tf_chat_head, which 15_mobile.css uses for a darker matte background.
   Nothing is created, moved, resized or hidden. An "@name" inside menus / sheets ( not at the top of the screen ) is ignored. */
(function(){
  "use strict";
  var MSG = ".message_wrapper,.group_new_message", SKIP = /^(SCRIPT|STYLE|TEXTAREA|NOSCRIPT|INPUT)$/, lastFail = 0;
  function onTop( e ){ var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.top > -2 && r.top < 260 && r.bottom > 0 }
  function find(){
    var w = document.createTreeWalker( document.body, NodeFilter.SHOW_TEXT, null, false ), vw = window.innerWidth, n, t, p, q, h, r;
    while ( ( n = w.nextNode() ) ){
      p = n.parentElement;
      if ( !p || SKIP.test( p.tagName ) ) continue;
      t = ( p.textContent || "" ).replace( /\s+/g, "" );
      if ( t.length < 2 || t.length > 64 || t.charAt( 0 ) !== "@" ) continue;
      if ( p.closest( MSG + ",._message" ) || !onTop( p ) ) continue;
      h = null;
      for ( q = p; q && q !== document.body && q !== document.documentElement; q = q.parentElement ){
        if ( q.querySelector( MSG ) ) break;
        r = q.getBoundingClientRect();
        if ( r.height > 140 ) break;
        if ( r.width >= vw * 0.85 && r.height >= 28 && r.top < 260 ) h = q;
      }
      if ( h ) return h;
    }
    return null;
  }
  function clear( keep ){
    var l = document.querySelectorAll( ".tf_chat_head" ), i;
    for ( i = 0; i < l.length; i++ ) if ( l[ i ] !== keep ) l[ i ].classList.remove( "tf_chat_head" );
  }
  function apply(){
    try {
      var b = document.body, m = document.getElementById( "messenger" ), cur, h;
      if ( !b ) return;
      if ( !m || !b.classList.contains( "mobile" ) || !m.querySelector( MSG ) ){ clear( null ); return }
      cur = document.querySelector( ".tf_chat_head" );
      if ( cur && cur.isConnected !== false && document.body.contains( cur ) ) return;     /* already marked ( stays marked while scrolling ) */
      if ( Date.now() - lastFail < 700 ) return;                                          /* nothing found a moment ago: do not search again at once */
      h = find();
      clear( h );
      if ( h ) h.classList.add( "tf_chat_head" ); else lastFail = Date.now();
    } catch ( e ) {}
  }
  var timer = 0;
  function soon(){ if ( !timer ) timer = setTimeout( function(){ timer = 0; apply() }, 200 ) }
  function init(){
    if ( !document.body ) return;
    apply();
    if ( window.MutationObserver ) new MutationObserver( soon ).observe( document.body, { childList: true, subtree: true } );
    setInterval( apply, 1000 );
  }
  if ( document.body ) init(); else document.addEventListener( "DOMContentLoaded", init );
})();

;
/* ===== Explore Tracks ( /tracks ) / Explore Artists ( /artists ) pages: tells the CSS ( 15_mobile.css ) which of the two pages is open =====
   Only sets html.tf_xp_t / html.tf_xp_a. Nothing else is touched. */
(function(){
  "use strict";
  var root = document.documentElement, last = null;
  function sync(){
    var p = "", t, a;
    try { p = location.pathname.replace( /\/+$/, "" ).toLowerCase() } catch( e ){}
    if ( p === last ) return;
    last = p;
    t = p === "/tracks"; a = p === "/artists";
    root.classList.toggle( "tf_xp_t", t );
    root.classList.toggle( "tf_xp_a", a );
  }
  sync();
  setInterval( sync, 300 );
  window.addEventListener( "popstate", sync );
})();;(function(){ "use strict"; try { document.addEventListener( "touchstart", function(){}, { passive: true } ) } catch( e ){} var root = document.documentElement, last = [], mq = window.matchMedia ? matchMedia( "(prefers-reduced-motion: reduce)" ) : null; function pick(){ if ( ( !root.classList.contains( "tf_xp_t" ) && !root.classList.contains( "tf_xp_a" ) ) || document.hidden || ( mq && mq.matches ) ) return; var all = document.querySelectorAll( "#main .widget .list_wrapper .item" ), vis = [], i, r, h = window.innerHeight || 800; for ( i = 0; i < all.length; i++ ){ r = all[ i ].getBoundingClientRect(); if ( r.bottom > 60 && r.top < h - 60 && r.width > 0 ) vis.push( all[ i ] ) } var pool = vis.filter( function( e ){ return last.indexOf( e ) < 0 } ); if ( pool.length < 2 ) pool = vis; var chosen = []; while ( chosen.length < 2 && pool.length ){ chosen.push( pool.splice( Math.floor( Math.random() * pool.length ), 1 )[ 0 ] ) } last = chosen; chosen.forEach( function( e ){ e.classList.add( "tf_xp_sh" ); setTimeout( function(){ e.classList.remove( "tf_xp_sh" ) }, 1700 ) } ); } setTimeout( function loop(){ pick(); setTimeout( loop, 2400 ) }, 1800 ); })();
;(function(){ "use strict"; var root = document.documentElement, lastPath = null, busy = 0; var RULES = [ [ "tv",    /(^|[^a-z])tv([^a-z]|$)|television|تلویزیون|تلویزیونی|تی\s?وی/i ], [ "radio", /radio|رادیو/i ], [ "cat",   /categor|دسته/i ], [ "lang",  /language|زبان/i ] ]; var KEYS = [ "live", "radio", "tv", "cat", "lang" ]; function isLive(){ var p = ""; try { p = location.pathname.replace( /\/+$/, "" ).toLowerCase() } catch( e ){} return p === "/radio"; } function titleOf( w ){ var t = w.querySelector( ".widget_content > .title" ), a; if ( !t ) return ""; a = t.querySelector( "a:not(._more)" ); return ( ( a || t ).textContent || "" ).trim(); } function keyOf( w ){ var i, s; if ( w.querySelector( ".table_wrapper" ) ) return "live"; s = titleOf( w ); for ( i = 0; i < RULES.length; i++ ) if ( RULES[ i ][ 1 ].test( s ) ) return RULES[ i ][ 0 ]; if ( w.querySelector( ".slider_wrapper" ) ) return "tv"; if ( w.classList.contains( "cols_1" ) ) return "lang"; if ( w.querySelector( ".list_wrapper" ) ) return "radio"; return ""; } function ambient( w ){ var imgs = w.querySelectorAll( ".slider_wrapper .item .cover_wrapper img" ), i; for ( i = 0; i < imgs.length; i++ ) ( function( img ){ var cw = img.closest( ".cover_wrapper" ); function set(){ var s = img.currentSrc || img.src; if ( s && cw ) cw.style.setProperty( "--lv-img", "url(\"" + s.replace( /"/g, "%22" ) + "\")" ); } if ( !cw || cw.getAttribute( "data-lv" ) === ( img.currentSrc || img.src ) ) return; set(); cw.setAttribute( "data-lv", img.currentSrc || img.src || "1" ); if ( !img.complete ) img.addEventListener( "load", set, { once: true } ); } )( imgs[ i ] ); } function fixName( w ){ var t = w.querySelector( ".widget_content > .title" ), a, n, v; if ( !t ) return; a = t.querySelector( "a:not(._more)" ) || t; for ( n = a.firstChild; n; n = n.nextSibling ){ if ( n.nodeType !== 3 ) continue; v = n.nodeValue.replace( /tunefa/ig, "TuneFA" ); if ( v !== n.nodeValue ) n.nodeValue = v; } } function blueLive( w ){ var t = w.querySelector( ".widget_content > .title" ), a, n, m, s; if ( !t || t.querySelector( ".tf_lv_blue" ) ) return; a = t.querySelector( "a:not(._more)" ) || t; n = a.lastChild; while ( n && !( n.nodeType === 3 && /live/i.test( n.nodeValue ) ) ) n = n.previousSibling; if ( !n ) return; m = /^([\s\S]*?)(live)([\s\S]*)$/i.exec( n.nodeValue ); if ( !m ) return; s = document.createElement( "span" ); s.className = "tf_lv_blue"; s.textContent = m[ 2 ]; n.nodeValue = m[ 1 ]; n.parentNode.insertBefore( s, n.nextSibling ); if ( m[ 3 ] ) s.parentNode.insertBefore( document.createTextNode( m[ 3 ] ), s.nextSibling ); } function tag(){ busy = 0; if ( !root.classList.contains( "tf_live" ) ) return; var ws = document.querySelectorAll( "#main .widget" ), i, k, j, has; for ( i = 0; i < ws.length; i++ ){ k = keyOf( ws[ i ] ); for ( j = 0; j < KEYS.length; j++ ){ has = ws[ i ].classList.contains( "tf_lv_" + KEYS[ j ] ); if ( KEYS[ j ] === k ){ if ( !has ) ws[ i ].classList.add( "tf_lv_" + k ) } else if ( has ) ws[ i ].classList.remove( "tf_lv_" + KEYS[ j ] ); } if ( k === "tv" ) ambient( ws[ i ] ); if ( k === "live" ){ fixName( ws[ i ] ); blueLive( ws[ i ] ); } } } function soon(){ if ( !busy ) busy = requestAnimationFrame( tag ) } function sync(){ var on = isLive(), p = on ? "1" : "0"; if ( p !== lastPath ){ lastPath = p; root.classList.toggle( "tf_live", on ) } if ( on ) soon(); } function init(){ sync(); setInterval( sync, 300 ); window.addEventListener( "popstate", sync ); if ( window.MutationObserver ) new MutationObserver( function(){ if ( root.classList.contains( "tf_live" ) ) soon() } ) .observe( document.body, { childList: true, subtree: true } ); } if ( document.body ) init(); else document.addEventListener( "DOMContentLoaded", init ); })();

;
(function(){
"use strict";
var DELAY_MIN  = 2000;
var DELAY_MAX  = 2000;
var HOME_PATHS = [ "", "/index.html" ];
var K_DONE = "tf_pwa_installed";
var IGNORE_LOAD_CLASSES_AFTER = 25000;
var T0 = Date.now(), mem = {}, root = document.documentElement;
var card = null, sheet = null, timer = 0, showing = false, shownOnce = false, dp = null, lastFocus = null, hideT = 0;
function get( k ){
var v = null;
try { v = window.localStorage.getItem( k ) } catch( e ){}
return v == null ? ( mem[ k ] == null ? null : mem[ k ] ) : v;
}
function set( k, v ){
mem[ k ] = String( v );
try { window.localStorage.setItem( k, String( v ) ) } catch( e ){}
}
function isFa(){return true}
function isIos(){
var u = navigator.userAgent || "";
return /iPad|iPhone|iPod/.test( u ) || ( navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1 );
}
function isAndroid(){ return /Android/i.test( navigator.userAgent || "" ) }
function installedContext(){
var i, q = [ "standalone", "minimal-ui", "window-controls-overlay" ];
try { if ( navigator.standalone === true ) return true } catch( e ){}
try { for ( i = 0; i < q.length; i++ ) if ( window.matchMedia( "(display-mode: " + q[ i ] + ")" ).matches ) return true } catch( e ){}
try { if ( ( document.referrer || "" ).indexOf( "android-app://" ) === 0 ) return true } catch( e ){}
return false;
}
function isHome(){
var p = "";
try { p = location.pathname.replace( /\/+$/, "" ).toLowerCase() } catch( e ){}
return HOME_PATHS.indexOf( p ) > -1;
}
function siteReady(){
var b = document.body, sp, old = Date.now() - T0 > IGNORE_LOAD_CLASSES_AFTER;
if ( !b || !b.classList.contains( "mobile" ) ) return false;
if ( b.classList.contains( "loading" ) ) return false;
if ( !old && ( b.classList.contains( "splash" ) || b.classList.contains( "unloaded" ) ) ) return false;
sp = document.getElementById( "tf_splash" );
if ( sp && ( sp.classList.contains( "tf_show" ) || sp.classList.contains( "tf_run" ) ) ) return false;
return !!document.querySelector( "#main .content" );
}
function playerOrOverlayOpen(){
var b = document.body;
if ( b.classList.contains( "muse_active" ) && !b.classList.contains( "muse_hide" ) ) return true;
if ( b.classList.contains( "que_active" ) || b.classList.contains( "que_active_open" ) ) return true;
if ( b.classList.contains( "sidebar_fl_show" ) || b.classList.contains( "fullMenuOpened" ) ) return true;
return !!document.querySelector( ".widgetItemButtons_hover" );
}
function suppressed(){
return get( K_DONE ) === "1";
}
function eligible(){
return siteReady() && isHome() && !suppressed() && !playerOrOverlayOpen();
}
function canShow(){
return !document.hidden && eligible();
}
var TXT = {
fa: {
title: "TuneFA را نصب کن", sub: "دسترسی سریع‌تر به موزیک، بدون مرورگر", btn: "نصب", close: "بستن", ok: "متوجه شدم",
sets: {
ios: {
how: "نصب TuneFA روی آیفون", sub: "با ۳ قدم ساده، TuneFA مثل یک اپلیکیشن روی صفحه اصلی‌ات می‌نشیند.",
steps: [
[ "share", "در نوار پایین Safari روی دکمه <em>اشتراک‌گذاری</em> (Share) بزن؛ مربعی با فلشی رو به بالا." ],
[ "plus",  "کمی به پایین اسکرول کن و <em>افزودن به صفحه اصلی</em> (Add to Home Screen) را انتخاب کن." ],
[ "check", "بالا سمت راست روی <em>افزودن</em> (Add) بزن. آیکون TuneFA همان لحظه به صفحه اصلی اضافه می‌شود." ]
],
note: "نکته: نصب روی آیفون فقط از Safari انجام می‌شود. اگر سایت را در مرورگر دیگری باز کرده‌ای، آدرس را در Safari باز کن."
},
android: {
how: "نصب TuneFA روی اندروید", sub: "با ۳ قدم ساده، TuneFA مثل یک اپلیکیشن روی گوشی‌ات نصب می‌شود.",
steps: [
[ "dots",  "در Chrome روی منوی <em>سه‌نقطه</em> (⋮) بالای صفحه بزن." ],
[ "plus",  "گزینه <em>نصب برنامه</em> (Install app) یا <em>افزودن به صفحه اصلی</em> (Add to Home screen) را انتخاب کن." ],
[ "check", "در پنجره‌ی باز‌شده روی <em>نصب</em> (Install) بزن. آیکون TuneFA به صفحه اصلی و لیست برنامه‌ها اضافه می‌شود." ]
],
note: ""
},
samsung: {
how: "نصب TuneFA روی گوشی سامسونگ", sub: "با ۳ قدم ساده، TuneFA را به صفحه اصلی‌ات اضافه کن.",
steps: [
[ "menu",  "در Samsung Internet روی منوی <em>سه‌خط</em> (≡) پایین صفحه بزن." ],
[ "plus",  "گزینه <em>افزودن صفحه به</em> (Add page to) و بعد <em>صفحه اصلی</em> (Home screen) را انتخاب کن." ],
[ "check", "روی <em>افزودن</em> (Add) بزن. آیکون TuneFA به صفحه اصلی اضافه می‌شود." ]
],
note: ""
},
firefox: {
how: "نصب TuneFA در Firefox", sub: "با ۳ قدم ساده، TuneFA را به صفحه اصلی‌ات اضافه کن.",
steps: [
[ "dots",  "روی منوی <em>سه‌نقطه</em> (⋮) در Firefox بزن." ],
[ "plus",  "گزینه <em>نصب</em> (Install) را انتخاب کن." ],
[ "check", "نصب را <em>تأیید</em> کن. آیکون TuneFA به صفحه اصلی اضافه می‌شود." ]
],
note: ""
},
other: {
how: "نصب TuneFA", sub: "با ۳ قدم ساده، TuneFA را به صفحه اصلی‌ات اضافه کن.",
steps: [
[ "dots",  "منوی مرورگرت را باز کن." ],
[ "plus",  "گزینه <em>نصب برنامه</em> (Install app) یا <em>افزودن به صفحه اصلی</em> (Add to Home screen) را پیدا کن و بزن." ],
[ "check", "نصب را <em>تأیید</em> کن. آیکون TuneFA به صفحه اصلی اضافه می‌شود." ]
],
note: ""
}
}
},
en: {
title: "Install TuneFA", sub: "Faster music access, no browser", btn: "Install", close: "Close", ok: "Got it",
sets: {
ios: {
how: "Install TuneFA on iPhone", sub: "3 quick steps and TuneFA sits on your Home Screen like a real app.",
steps: [
[ "share", "In Safari's bottom bar, tap the <em>Share</em> button: a square with an arrow pointing up." ],
[ "plus",  "Scroll down the menu and tap <em>Add to Home Screen</em>." ],
[ "check", "Tap <em>Add</em> at the top right. The TuneFA icon appears on your Home Screen right away." ]
],
note: "Tip: on iPhone, installing works from Safari only. If you opened the site in another browser, open the address in Safari first."
},
android: {
how: "Install TuneFA on Android", sub: "3 quick steps and TuneFA is installed like a real app.",
steps: [
[ "dots",  "In Chrome, tap the <em>three-dot menu</em> (⋮) at the top of the screen." ],
[ "plus",  "Tap <em>Install app</em> or <em>Add to Home screen</em>." ],
[ "check", "In the pop-up, tap <em>Install</em>. The TuneFA icon is added to your Home screen and app list." ]
],
note: ""
},
samsung: {
how: "Install TuneFA on Samsung", sub: "3 quick steps to add TuneFA to your Home screen.",
steps: [
[ "menu",  "In Samsung Internet, tap the <em>menu</em> (≡) at the bottom of the screen." ],
[ "plus",  "Tap <em>Add page to</em>, then choose <em>Home screen</em>." ],
[ "check", "Tap <em>Add</em>. The TuneFA icon appears on your Home screen." ]
],
note: ""
},
firefox: {
how: "Install TuneFA in Firefox", sub: "3 quick steps to add TuneFA to your Home screen.",
steps: [
[ "dots",  "Tap the <em>three-dot menu</em> (⋮) in Firefox." ],
[ "plus",  "Tap <em>Install</em>." ],
[ "check", "<em>Confirm</em> the install. The TuneFA icon appears on your Home screen." ]
],
note: ""
},
other: {
how: "Install TuneFA", sub: "3 quick steps to add TuneFA to your Home screen.",
steps: [
[ "dots",  "Open your browser's menu." ],
[ "plus",  "Find and tap <em>Install app</em> or <em>Add to Home screen</em>." ],
[ "check", "<em>Confirm</em> the install. The TuneFA icon appears on your Home screen." ]
],
note: ""
}
}
}
};
var ICON = {
share: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15V3M8 7l4-4 4 4M6 11H5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-8a1 1 0 0 0-1-1h-1"/></svg>',
plus:  '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="16" height="16" rx="4"/><path d="M12 8.5v7M8.5 12h7"/></svg>',
dots:  '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="5.5" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="12" cy="18.5" r="1.4"/></svg>',
menu:  '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14M5 12h14M5 17h14"/></svg>',
check: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="m8.6 12.2 2.4 2.4 4.4-4.8"/></svg>'
};
function build(){
var t = TXT[ isFa() ? "fa" : "en" ], rtl = isFa(), el = document.createElement( "div" );
el.id = "tf_pwa";
el.setAttribute( "role", "region" );
el.setAttribute( "aria-label", t.title );
el.innerHTML =
'<div class="tf_pwa_card">' +
'<span class="tf_pwa_ic" aria-hidden="true"></span>' +
'<div class="tf_pwa_tx" dir="' + ( rtl ? "rtl" : "ltr" ) + '" lang="' + ( rtl ? "fa" : "en" ) + '"><b></b><small></small></div>' +
'<div class="tf_pwa_act">' +
'<button type="button" class="tf_pwa_btn"></button>' +
'<button type="button" class="tf_pwa_x"><svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2 2l8 8M10 2l-8 8"/></svg></button>' +
'</div>' +
'</div>';
el.querySelector( "b" ).textContent = t.title;
el.querySelector( "small" ).textContent = t.sub;
el.querySelector( ".tf_pwa_btn" ).textContent = t.btn;
el.querySelector( ".tf_pwa_x" ).setAttribute( "aria-label", t.close );
el.querySelector( ".tf_pwa_btn" ).addEventListener( "click", onInstall );
el.querySelector( ".tf_pwa_x" ).addEventListener( "click", function(){ dismiss() } );
return el;
}
function show(){
if ( showing ) return;
clearTimeout( hideT );
if ( card && card.parentNode ) card.parentNode.removeChild( card );
card = build();
document.body.appendChild( card );
showing = true; shownOnce = true;
void card.offsetWidth;
requestAnimationFrame( function(){ if ( card && showing ) card.classList.add( "tf_in" ) } );
}
function hide( then ){
var c = card;
if ( !c ) { showing = false; if ( then ) then(); return }
showing = false;
c.classList.remove( "tf_in" );
c.classList.add( "tf_out" );
clearTimeout( hideT );
hideT = setTimeout( function(){
if ( c.parentNode ) c.parentNode.removeChild( c );
if ( card === c ) card = null;
if ( then ) then();
}, 360 );
}
function dismiss(){
hide();
}
function installed(){
set( K_DONE, "1" );
dp = null;
closeSheet( true );
if ( showing ) hide();
}
function onInstall(){
var p = dp;
if ( p && typeof p.prompt === "function" ){
dp = null;
try {
var r = p.prompt();
if ( r && typeof r.catch === "function" ) r.catch( function(){} );
if ( p.userChoice && typeof p.userChoice.then === "function" ){
p.userChoice.then( function( c ){
if ( c && c.outcome === "accepted" ) installed(); else dismiss();
}, function(){} );
}
return;
} catch( e ){}
}
openSheet();
}
function sheetKind(){
var u = navigator.userAgent || "";
if ( isIos() ) return "ios";
if ( !isAndroid() ) return "other";
if ( /SamsungBrowser/i.test( u ) ) return "samsung";
if ( /Firefox|FxiOS/i.test( u ) ) return "firefox";
return "android";
}
function openSheet(){
if ( sheet ) return;
var rtl = isFa(), t = TXT[ rtl ? "fa" : "en" ], set = t.sets[ sheetKind() ], steps = set.steps, i, li = "", s;
for ( i = 0; i < steps.length; i++ )
li += '<li><span class="tf_pwa_n">' + ( rtl ? [ "۱", "۲", "۳" ][ i ] : ( i + 1 ) ) + '</span>' +
'<span class="tf_pwa_t">' + steps[ i ][ 1 ] + '</span>' +
'<span class="tf_pwa_i">' + ICON[ steps[ i ][ 0 ] ] + '</span></li>';
s = document.createElement( "div" );
s.id = "tf_pwa_sheet";
s.setAttribute( "dir", rtl ? "rtl" : "ltr" );
s.setAttribute( "lang", rtl ? "fa" : "en" );
s.innerHTML =
'<div class="tf_pwa_pane" role="dialog" aria-modal="true" aria-labelledby="tf_pwa_h">' +
'<div class="tf_pwa_grab"></div>' +
'<h3 id="tf_pwa_h"></h3><p class="tf_pwa_sub"></p>' +
'<ol>' + li + '</ol>' + ( set.note ? '<p class="tf_pwa_note"></p>' : '' ) +
'<button type="button" class="tf_pwa_ok"></button>' +
'</div>';
s.querySelector( "h3" ).textContent = set.how;
s.querySelector( ".tf_pwa_sub" ).textContent = set.sub;
if ( set.note ) s.querySelector( ".tf_pwa_note" ).textContent = set.note;
s.querySelector( ".tf_pwa_ok" ).textContent = t.ok;
s.querySelector( ".tf_pwa_ok" ).addEventListener( "click", function(){ closeSheet() } );
s.addEventListener( "click", function( e ){ if ( e.target === s ) closeSheet() } );
lastFocus = document.activeElement;
document.body.appendChild( s );
sheet = s;
void s.offsetWidth;
requestAnimationFrame( function(){ if ( sheet === s ){ s.classList.add( "tf_in" ); try { s.querySelector( ".tf_pwa_ok" ).focus( { preventScroll: true } ) } catch( e ){} } } );
}
function closeSheet( now ){
var s = sheet;
if ( !s ) return;
sheet = null;
s.classList.remove( "tf_in" );
function rm(){ if ( s.parentNode ) s.parentNode.removeChild( s ) }
if ( now ) rm(); else setTimeout( rm, 440 );
try { if ( lastFocus && lastFocus.focus ) lastFocus.focus( { preventScroll: true } ) } catch( e ){}
lastFocus = null;
}
function sync(){
if ( installedContext() ){
set( K_DONE, "1" );
if ( timer ){ clearTimeout( timer ); timer = 0 }
if ( showing ) hide();
return;
}
if ( showing ){
if ( !sheet && !eligible() ) hide();
return;
}
if ( !shownOnce && canShow() ){
if ( !timer ) timer = setTimeout( fire, DELAY_MIN + Math.random() * ( DELAY_MAX - DELAY_MIN ) );
} else if ( timer ){
clearTimeout( timer ); timer = 0;
}
}
function fire(){
timer = 0;
if ( canShow() && !installedContext() ) show();
}
function init(){
window.addEventListener( "appinstalled", installed );
window.addEventListener( "popstate", sync );
document.addEventListener( "visibilitychange", sync );
document.addEventListener( "keydown", function( e ){ if ( ( e.key === "Escape" || e.keyCode === 27 ) && sheet ) closeSheet() } );
if ( window.MutationObserver ) new MutationObserver( sync ).observe( document.body, { attributes: true, attributeFilter: [ "class" ] } );
setInterval( sync, 500 );
try {
if ( navigator.getInstalledRelatedApps ) navigator.getInstalledRelatedApps().then( function( a ){ if ( a && a.length ) installed() }, function(){} );
} catch( e ){}
sync();
}
window.addEventListener( "beforeinstallprompt", function( e ){
if ( get( K_DONE ) === "1" || installedContext() ) return;
e.preventDefault();
dp = e;
} );
if ( document.body ) init(); else document.addEventListener( "DOMContentLoaded", init );
})();
